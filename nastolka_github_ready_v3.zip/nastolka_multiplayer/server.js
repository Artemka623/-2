const http = require("http");
const fs = require("fs");
const path = require("path");
const { WebSocketServer, WebSocket } = require("ws");

const PORT = Number(process.env.PORT || 3000);
const ROOT = __dirname;
const rooms = new Map();

function code() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let out = "";
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}
function publicRoom(room) {
  return {
    code: room.code, hostId: room.hostId, scores: room.scores,
    active: room.active, seconds: room.seconds, word: room.word,
    mode: room.mode, positions: room.positions, dieFace: room.dieFace,
    players: [...room.players.values()].map(p => ({
      id: p.id, name: p.name, team: p.team, connected: p.connected
    }))
  };
}
function send(ws, obj) {
  if (ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify(obj));
}
function broadcast(room) {
  const message = JSON.stringify({ type: "state", room: publicRoom(room) });
  for (const p of room.players.values()) {
    if (p.ws && p.ws.readyState === WebSocket.OPEN) p.ws.send(message);
  }
}
function stopTimer(room) {
  if (room.timer) clearInterval(room.timer);
  room.timer = null;
}
function createRoom(ws, data) {
  let roomCode;
  do { roomCode = code(); } while (rooms.has(roomCode));
  const id = String(data.playerId || require("crypto").randomUUID()).slice(0, 80);
  const room = {
    code: roomCode, hostId: id, players: new Map(),
    scores: [0, 0], active: 0, seconds: 60, word: "",
    mode: -1, positions: [0, 0], dieFace: 0, timer: null
  };
  rooms.set(roomCode, room);
  addPlayer(room, ws, { ...data, playerId: id });
  send(ws, { type: "created", player: { id }, room: publicRoom(room) });
}
function addPlayer(room, ws, data) {
  const id = String(data.playerId || require("crypto").randomUUID()).slice(0, 80);
  const existing = room.players.get(id);
  const player = existing || {
    id, name: "Игрок", team: room.players.size % 2
  };
  player.name = String(data.name || player.name).slice(0, 22);
  player.connected = true;
  player.ws = ws;
  room.players.set(id, player);
  ws.playerId = id;
  ws.roomCode = room.code;
  return player;
}
function joinRoom(ws, data) {
  const room = rooms.get(String(data.code || "").toUpperCase());
  if (!room) return send(ws, { type: "error", message: "Комната не найдена. Проверьте код." });
  if (room.players.size >= 16 && !room.players.has(data.playerId)) {
    return send(ws, { type: "error", message: "В комнате максимум 16 игроков." });
  }
  const player = addPlayer(room, ws, data);
  send(ws, { type: "joined", player: { id: player.id }, room: publicRoom(room) });
  broadcast(room);
}
function applyAction(room, ws, data) {
  const action = data.action;
  if (action === "score") {
    const delta = Math.max(-10, Math.min(10, Number(data.delta) || 0));
    room.scores[room.active] = Math.max(0, room.scores[room.active] + delta);
  } else if (action === "switch") {
    room.active = 1 - room.active;
    room.seconds = 60;
    stopTimer(room);
  } else if (action === "roll") {
    room.mode = Math.floor(Math.random() * 4);
    room.dieFace = 1 + Math.floor(Math.random() * 6);
    room.positions[room.active] = Math.min(24, room.positions[room.active] + room.dieFace);
    room.word = randomWord();
  } else if (action === "nextWord") {
    room.word = randomWord(room.word);
  } else if (action === "timerStart") {
    if (!room.timer && room.seconds > 0) {
      room.timer = setInterval(() => {
        room.seconds = Math.max(0, room.seconds - 1);
        if (room.seconds === 0) stopTimer(room);
        broadcast(room);
      }, 1000);
    }
  } else if (action === "timerReset") {
    stopTimer(room);
    room.seconds = 60;
  } else if (action === "reset") {
    stopTimer(room);
    room.scores = [0, 0]; room.active = 0; room.seconds = 60;
    room.word = ""; room.mode = -1; room.positions = [0, 0]; room.dieFace = 0;
  }
  broadcast(room);
}
const wordList = ["Космонавт","Попкорн","Карусель","Динозавр","Пылесос","Свадьба","Пингвин","Телепорт","Кактус","Будильник","Русалка","Чемодан","Караоке","Библиотека","Супергерой","Мороженое","Пират","Самокат","Облако","Вулкан","Шахматы","Бабушка","Светофор","Подводная лодка","Тираннозавр","Зубная щётка","Фейерверк","Танцор","Микроволновка","Виноград"];
function randomWord(previous = "") {
  let word;
  do { word = wordList[Math.floor(Math.random() * wordList.length)]; }
  while (word === previous && wordList.length > 1);
  return word;
}

const server = http.createServer((req, res) => {
  let pathname = decodeURIComponent((req.url || "/").split("?")[0]);
  if (pathname === "/") pathname = "/index.html";
  const safe = path.normalize(pathname).replace(/^(\.\.[/\\])+/, "");
  const file = path.join(ROOT, safe);
  if (!file.startsWith(ROOT)) { res.writeHead(403); return res.end("Forbidden"); }
  fs.readFile(file, (err, content) => {
    if (err) { res.writeHead(404); return res.end("Not found"); }
    const ext = path.extname(file);
    const types = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".json": "application/json; charset=utf-8" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "X-Content-Type-Options": "nosniff" });
    res.end(content);
  });
});
const wss = new WebSocketServer({ server, path: "/ws" });
wss.on("connection", ws => {
  ws.on("message", raw => {
    let data;
    try { data = JSON.parse(raw.toString()); } catch { return send(ws, { type: "error", message: "Некорректное сообщение." }); }
    if (data.type === "create") return createRoom(ws, data);
    if (data.type === "join") return joinRoom(ws, data);
    if (data.type === "leave") {
      const room = rooms.get(ws.roomCode);
      if (room) {
        const p = room.players.get(ws.playerId);
        if (p) { p.connected = false; p.ws = null; }
        broadcast(room);
      }
      return;
    }
    if (data.type === "action") {
      const room = rooms.get(ws.roomCode);
      if (room && room.players.has(ws.playerId)) applyAction(room, ws, data);
    }
  });
  ws.on("close", () => {
    const room = rooms.get(ws.roomCode);
    if (room) {
      const p = room.players.get(ws.playerId);
      if (p && p.ws === ws) { p.connected = false; p.ws = null; }
      broadcast(room);
    }
  });
});
server.listen(PORT, "0.0.0.0", () => {
  console.log(`Настолка multiplayer запущена на порту ${PORT}`);
});

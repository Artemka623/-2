// Вставьте сюда HTTPS-домен вашего Node.js сервера без завершающего слэша.
// Пример: const WS_SERVER_URL = 'https://game.example.ru';
// После настройки сайт подключится к wss://game.example.ru/ws
const WS_SERVER_URL = '';
